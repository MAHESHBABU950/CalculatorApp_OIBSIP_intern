package com.example.mycalculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private double num1 = 0;
    private String operator = "";
    private boolean isOperatorClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);

        // Set click listeners for number buttons (0-9)
        for (int n = 0; n <= 9; n++) {
            int resID = getResources().getIdentifier("button" + n, "id", getPackageName());
            Button button = findViewById(resID);
            int finalN = n;
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onDigitButtonClick(finalN);
                }
            });
        }

        // Set click listeners for operator buttons (+, -, *, /, =)
        Button buttonPlus = findViewById(R.id.buttonPlus);
        Button buttonMinus = findViewById(R.id.buttonMinus);
        Button buttonMultiply = findViewById(R.id.buttonMultiply);
        Button buttonDivide = findViewById(R.id.buttonDivide);
        Button buttonEquals = findViewById(R.id.buttonEquals);
        Button buttonModulus = findViewById(R.id.buttonmodulus);
        Button buttonDelete = findViewById(R.id.buttondelete);

        buttonPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOperatorButtonClick("+");
            }
        });

        buttonMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOperatorButtonClick("-");
            }
        });

        buttonMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOperatorButtonClick("*");
            }
        });

        buttonDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOperatorButtonClick("/");
            }
        });

        buttonModulus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOperatorButtonClick("%");
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDeleteButtonClick();
            }
        });

        buttonEquals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onEqualsButtonClick();
            }
        });

        // Clear the input field
        Button buttonClear = findViewById(R.id.buttonClear);
        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearInput();
            }
        });
    }

    private void onDigitButtonClick(int digit) {
        if (isOperatorClicked) {
            editText.setText(String.valueOf(digit));
            isOperatorClicked = false;
        } else {
            String currentText = editText.getText().toString();
            if (currentText.equals("0")) {
                editText.setText(String.valueOf(digit));
            } else {
                editText.setText(currentText + digit);
            }
        }
    }

    private void onOperatorButtonClick(String newOperator) {
        if (!operator.isEmpty()) {
            onEqualsButtonClick(); // Perform calculation if there's a pending operation
        }
        num1 = Double.parseDouble(editText.getText().toString());
        operator = newOperator;
        isOperatorClicked = true;
    }

    private void onEqualsButtonClick() {
        if (!operator.isEmpty()) {
            double num2 = Double.parseDouble(editText.getText().toString());
            double result = 0;

            switch (operator) {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "%": // Handle modulus operation
                    result = num1 % num2;
                    break;
                case "/":
                    if (num2 != 0) {
                        result = num1 / num2;
                    } else {
                        editText.setText("Error");
                        return;
                    }
                    break;
            }

            editText.setText(String.valueOf(result));
            operator = "";
            isOperatorClicked = false;
        }
    }

    private void clearInput() {
        editText.setText("0");
        num1 = 0;
        operator = "";
        isOperatorClicked = false;
    }

    private void onDeleteButtonClick() {
        String currentText = editText.getText().toString();
        if (currentText.length() > 0) {
            // Remove the last character from the input field
            String newText = currentText.substring(0, currentText.length() - 1);
            editText.setText(newText);
        }
    }

}